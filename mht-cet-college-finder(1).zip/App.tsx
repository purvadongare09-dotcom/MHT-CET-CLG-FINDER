
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Contact from './pages/Contact';
import Blog from './pages/Blog';
import PostDetail from './pages/PostDetail';
import CollegeFinder from './pages/CollegeFinder';
import CollegeDetail from './pages/CollegeDetail';
import Dashboard from './pages/Admin/Dashboard';
import Login from './pages/Admin/Login';
import CollegeEditor from './pages/Admin/CollegeEditor';
import BlogEditor from './pages/Admin/BlogEditor';
import AdminSettings from './pages/Admin/AdminSettings';
import { getSettings } from './store';
import { SiteSettings } from './types';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('mhtcet_admin_auth') === 'true';
  });
  
  const [settings, setSettings] = useState<SiteSettings>(getSettings());

  const handleLogin = () => {
    setIsAuthenticated(true);
    localStorage.setItem('mhtcet_admin_auth', 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('mhtcet_admin_auth');
  };

  const refreshSettings = () => {
    setSettings(getSettings());
  };

  return (
    <HashRouter>
      <ScrollToTop />
      <div 
        className="flex flex-col min-h-screen" 
        style={{ '--primary-color': settings.primaryColor } as React.CSSProperties}
      >
        <Navbar isAuthenticated={isAuthenticated} onLogout={handleLogout} />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/finder" element={<CollegeFinder />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<PostDetail />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/college/:slug" element={<CollegeDetail />} />
            
            <Route 
              path="/admin" 
              element={isAuthenticated ? <Dashboard /> : <Login onLogin={handleLogin} />} 
            />
            <Route 
              path="/admin/college/:id?" 
              element={isAuthenticated ? <CollegeEditor /> : <Login onLogin={handleLogin} />} 
            />
            <Route 
              path="/admin/blog/:id?" 
              element={isAuthenticated ? <BlogEditor /> : <Login onLogin={handleLogin} />} 
            />
            <Route 
              path="/admin/settings" 
              element={isAuthenticated ? <AdminSettings onUpdate={refreshSettings} /> : <Login onLogin={handleLogin} />} 
            />
          </Routes>
        </main>
        <Footer />
      </div>
    </HashRouter>
  );
};

export default App;
