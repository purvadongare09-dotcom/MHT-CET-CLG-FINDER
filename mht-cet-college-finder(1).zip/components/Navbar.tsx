
import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

interface NavbarProps {
  isAuthenticated: boolean;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ isAuthenticated, onLogout }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { label: 'Home', path: '/' },
    { label: 'College Finder', path: '/finder' },
    { label: 'Services', path: '/services' },
    { label: 'Blog', path: '/blog' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ];

  const activeClass = "text-blue-600 font-semibold border-b-2 border-blue-600 pb-1";
  const inactiveClass = "text-slate-600 hover:text-blue-600 transition-colors duration-200";

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold text-blue-700 tracking-tight">
              MHT-CET <span className="text-slate-800">Finder</span>
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <NavLink 
                key={item.path} 
                to={item.path}
                className={({ isActive }) => (isActive ? activeClass : inactiveClass)}
              >
                {item.label}
              </NavLink>
            ))}
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <Link 
                  to="/admin" 
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition"
                >
                  Admin Panel
                </Link>
                <button 
                  onClick={onLogout}
                  className="text-red-600 hover:text-red-700 font-medium"
                >
                  Logout
                </button>
              </div>
            ) : (
              <Link 
                to="/admin" 
                className="text-slate-500 hover:text-slate-700 text-sm font-medium border border-slate-300 px-3 py-1 rounded"
              >
                Admin
              </Link>
            )}
          </div>

          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-600 hover:text-blue-600 focus:outline-none"
            >
              <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 px-4 py-6 space-y-4">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className="block text-lg font-medium text-slate-700 hover:text-blue-600"
              onClick={() => setIsOpen(false)}
            >
              {item.label}
            </Link>
          ))}
          {isAuthenticated ? (
            <div className="space-y-4 pt-4">
              <Link
                to="/admin"
                className="block w-full text-center bg-blue-600 text-white py-3 rounded-lg"
                onClick={() => setIsOpen(false)}
              >
                Admin Panel
              </Link>
              <button
                onClick={() => { onLogout(); setIsOpen(false); }}
                className="block w-full text-center border border-red-200 text-red-600 py-3 rounded-lg"
              >
                Logout
              </button>
            </div>
          ) : (
            <Link
              to="/admin"
              className="block text-slate-500 font-medium pt-4"
              onClick={() => setIsOpen(false)}
            >
              Admin Login
            </Link>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
