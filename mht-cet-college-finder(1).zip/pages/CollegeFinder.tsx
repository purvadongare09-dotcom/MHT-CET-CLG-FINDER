
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Stream, District, College } from '../types';
import { getColleges } from '../store';

const CollegeFinder: React.FC = () => {
  const [step, setStep] = useState(1);
  const [selectedStream, setSelectedStream] = useState<Stream | null>(null);
  const [selectedDistrict, setSelectedDistrict] = useState<District | null>(null);
  const [filteredColleges, setFilteredColleges] = useState<College[]>([]);
  const [colleges, setColleges] = useState<College[]>([]);

  useEffect(() => {
    setColleges(getColleges());
  }, []);

  useEffect(() => {
    if (selectedStream && selectedDistrict) {
      const filtered = colleges.filter(
        c => c.stream === selectedStream && c.district === selectedDistrict
      );
      setFilteredColleges(filtered);
    }
  }, [selectedStream, selectedDistrict, colleges]);

  const handleStreamSelect = (stream: Stream) => {
    setSelectedStream(stream);
    setStep(2);
  };

  const handleDistrictSelect = (district: District) => {
    setSelectedDistrict(district);
    setStep(3);
  };

  const resetSearch = () => {
    setStep(1);
    setSelectedStream(null);
    setSelectedDistrict(null);
    setFilteredColleges([]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">MHT-CET College Finder</h1>
        <p className="text-slate-600 max-w-2xl mx-auto">
          Our intelligent search system helps you find the right college in three simple steps.
        </p>
      </div>

      {/* Progress Stepper */}
      <div className="max-w-3xl mx-auto flex items-center justify-between mb-16 relative px-4">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold z-10 ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'}`}>1</div>
        <div className={`flex-grow h-1 mx-2 z-0 ${step >= 2 ? 'bg-blue-600' : 'bg-slate-200'}`}></div>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold z-10 ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'}`}>2</div>
        <div className={`flex-grow h-1 mx-2 z-0 ${step >= 3 ? 'bg-blue-600' : 'bg-slate-200'}`}></div>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold z-10 ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-500'}`}>3</div>
      </div>

      {/* Step Content */}
      <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12 min-h-[400px]">
        {step === 1 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-2xl font-bold text-center">Step 1: Select Your Stream</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
              <button 
                onClick={() => handleStreamSelect(Stream.PCM)}
                className="group p-8 border-2 border-slate-100 rounded-2xl hover:border-blue-500 hover:bg-blue-50 transition text-left space-y-4"
              >
                <div className="text-3xl font-bold text-blue-600 group-hover:scale-110 transition">PCM</div>
                <div className="text-xl font-semibold">Engineering</div>
                <p className="text-slate-500 text-sm">Find BE/B.Tech colleges for various branches like CS, Mechanical, Civil, etc.</p>
              </button>
              <button 
                onClick={() => handleStreamSelect(Stream.PCB)}
                className="group p-8 border-2 border-slate-100 rounded-2xl hover:border-emerald-500 hover:bg-emerald-50 transition text-left space-y-4"
              >
                <div className="text-3xl font-bold text-emerald-600 group-hover:scale-110 transition">PCB</div>
                <div className="text-xl font-semibold">Pharmacy</div>
                <p className="text-slate-500 text-sm">Explore B.Pharm and Pharm.D colleges for your career in medicine.</p>
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="flex justify-between items-center">
              <button onClick={() => setStep(1)} className="text-blue-600 font-medium hover:underline">← Back to Stream</button>
              <h2 className="text-2xl font-bold">Step 2: Select Location</h2>
              <div className="w-20"></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[District.NAGPUR, District.PUNE, District.MUMBAI].map(dist => (
                <button 
                  key={dist}
                  onClick={() => handleDistrictSelect(dist)}
                  className="p-8 border-2 border-slate-100 rounded-2xl hover:border-blue-500 hover:bg-blue-50 transition text-center group"
                >
                  <div className="text-2xl font-bold text-slate-800 mb-2 group-hover:text-blue-600">{dist}</div>
                  <div className="text-sm text-slate-500 uppercase tracking-widest">District</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-8 animate-in fade-in zoom-in-95 duration-500">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <div>
                <h2 className="text-2xl font-bold">Search Results</h2>
                <p className="text-slate-500">Showing <span className="font-bold text-blue-600">{filteredColleges.length}</span> colleges in <span className="font-bold">{selectedDistrict}</span> for <span className="font-bold">{selectedStream}</span>.</p>
              </div>
              <button 
                onClick={resetSearch}
                className="bg-slate-100 text-slate-600 px-6 py-2 rounded-full font-semibold hover:bg-slate-200 transition"
              >
                New Search
              </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {filteredColleges.length > 0 ? (
                filteredColleges.map(college => (
                  <div key={college.id} className="p-6 border border-slate-100 rounded-2xl bg-slate-50 hover:bg-white hover:shadow-lg transition-all flex flex-col md:flex-row justify-between items-center gap-4">
                    <div className="text-center md:text-left">
                      <h3 className="text-xl font-bold text-slate-900 mb-1">{college.name}</h3>
                      <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                        <span className="text-xs font-semibold bg-blue-100 text-blue-700 px-2 py-1 rounded">Est: {college.estYear}</span>
                        <span className="text-xs font-semibold bg-indigo-100 text-indigo-700 px-2 py-1 rounded">NAAC: {college.naac}</span>
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <Link 
                        to={`/college/${college.slug}`}
                        className="text-blue-600 font-semibold hover:underline"
                      >
                        Details
                      </Link>
                      <a 
                        href={college.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-slate-600 font-semibold hover:text-slate-900 flex items-center gap-1"
                      >
                        Visit Website ↗
                      </a>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-20 bg-slate-50 rounded-2xl">
                  <div className="text-6xl mb-4">🔍</div>
                  <h3 className="text-xl font-semibold">No colleges found matching these criteria.</h3>
                  <p className="text-slate-500">Try changing your location or stream selection.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CollegeFinder;
