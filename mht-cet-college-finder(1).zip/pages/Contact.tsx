
import React, { useState } from 'react';

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="py-20 px-4 max-w-4xl mx-auto">
      <div className="text-center mb-16 space-y-4">
        <h1 className="text-4xl font-extrabold text-slate-900">Get in Touch</h1>
        <p className="text-slate-600">Have questions about a specific college? Our team is here to help.</p>
      </div>

      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden grid grid-cols-1 md:grid-cols-2">
        <div className="p-8 md:p-12 bg-blue-700 text-white space-y-8">
          <h2 className="text-2xl font-bold">Contact Information</h2>
          <div className="space-y-6">
            <div className="flex gap-4">
              <span className="text-xl">📍</span>
              <p>MHT-CET Finder Hub, Civil Lines, Nagpur - 440001</p>
            </div>
            <div className="flex gap-4">
              <span className="text-xl">📞</span>
              <p>+91 98765 43210</p>
            </div>
            <div className="flex gap-4">
              <span className="text-xl">✉️</span>
              <p>help@mhtcetfinder.edu.in</p>
            </div>
          </div>
        </div>

        <div className="p-8 md:p-12">
          {submitted ? (
            <div className="text-center py-12 space-y-4">
              <div className="text-6xl">✅</div>
              <h3 className="text-2xl font-bold">Message Sent!</h3>
              <p className="text-slate-500">We will get back to you within 24-48 hours.</p>
              <button 
                onClick={() => setSubmitted(false)}
                className="text-blue-600 font-bold hover:underline"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Full Name</label>
                <input required type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="John Doe" />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Email Address</label>
                <input required type="email" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="john@example.com" />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Message</label>
                <textarea required rows={4} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="How can we help you?"></textarea>
              </div>
              <button type="submit" className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl hover:bg-blue-700 transition">
                Send Message
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default Contact;
