
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { College } from '../types';
import { getColleges } from '../store';

const CollegeDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [college, setCollege] = useState<College | null>(null);

  useEffect(() => {
    const all = getColleges();
    const found = all.find(c => c.slug === slug);
    setCollege(found || null);
  }, [slug]);

  if (!college) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-24 text-center">
        <h1 className="text-2xl font-bold mb-4">College Not Found</h1>
        <p className="mb-8 text-slate-600">The college you are looking for does not exist in our database.</p>
        <Link to="/finder" className="bg-blue-600 text-white px-8 py-3 rounded-lg">Back to Finder</Link>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen py-12 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Breadcrumb */}
        <nav className="flex mb-8 text-sm text-slate-500">
          <Link to="/" className="hover:text-blue-600">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/finder" className="hover:text-blue-600">Colleges</Link>
          <span className="mx-2">/</span>
          <span className="text-slate-900 font-medium">{college.name}</span>
        </nav>

        {/* Header Block */}
        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-slate-100 mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-4">
              <span className="inline-block px-4 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wider">
                {college.stream === 'PCM' ? 'Engineering' : 'Pharmacy'} • {college.district}
              </span>
              <h1 className="text-3xl md:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
                {college.name}
              </h1>
            </div>
            <a 
              href={college.website} 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full md:w-auto text-center bg-blue-600 text-white px-8 py-4 rounded-xl font-bold shadow-lg hover:bg-blue-700 transition"
            >
              Visit Official Website
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Details */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
              <h2 className="text-2xl font-bold mb-6 border-b pb-4">Overview</h2>
              <p className="text-slate-700 leading-relaxed text-lg">
                {college.overview}
              </p>
              <div className="mt-8 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                <h4 className="font-bold text-slate-900 mb-4">Detailed Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                  <div className="flex flex-col">
                    <span className="text-slate-500 uppercase text-xs tracking-widest font-bold">Year of Establishment</span>
                    <span className="text-slate-900 font-semibold text-lg">{college.estYear}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-slate-500 uppercase text-xs tracking-widest font-bold">NAAC Accreditation</span>
                    <span className="text-slate-900 font-semibold text-lg">{college.naac}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-slate-500 uppercase text-xs tracking-widest font-bold">District</span>
                    <span className="text-slate-900 font-semibold text-lg">{college.district}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-slate-500 uppercase text-xs tracking-widest font-bold">Stream</span>
                    <span className="text-slate-900 font-semibold text-lg">{college.stream === 'PCM' ? 'Engineering (PCM)' : 'Pharmacy (PCB)'}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
              <h2 className="text-2xl font-bold mb-6 border-b pb-4">Admission Guidelines</h2>
              <p className="text-slate-600 mb-4">
                Admissions to this institution are conducted through the State Common Entrance Test Cell, Maharashtra.
              </p>
              <ul className="list-disc pl-5 space-y-3 text-slate-700">
                <li>Candidates must appear for the MHT-CET examination.</li>
                <li>Registration through the CAP portal is mandatory.</li>
                <li>Documentation verification must be completed at a facilitation center (FC).</li>
                <li>Merit list is generated based on CET percentiles and HSC scores (where applicable).</li>
              </ul>
            </div>
          </div>

          {/* Sidebar Info */}
          <div className="space-y-8">
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
              <h3 className="text-xl font-bold mb-6">Contact Details</h3>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-blue-50 text-blue-600 flex items-center justify-center rounded-lg font-bold">📍</div>
                  <div>
                    <span className="block text-xs text-slate-500 font-bold uppercase tracking-wider">Address</span>
                    <p className="text-slate-900 font-medium">{college.address}</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-emerald-50 text-emerald-600 flex items-center justify-center rounded-lg font-bold">📞</div>
                  <div>
                    <span className="block text-xs text-slate-500 font-bold uppercase tracking-wider">Phone</span>
                    <p className="text-slate-900 font-medium">{college.contact}</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 bg-indigo-50 text-indigo-600 flex items-center justify-center rounded-lg font-bold">🌐</div>
                  <div>
                    <span className="block text-xs text-slate-500 font-bold uppercase tracking-wider">Website</span>
                    <a href={college.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 font-medium hover:underline break-all">
                      {college.website}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-3xl p-8 shadow-lg text-white">
              <h3 className="text-xl font-bold mb-4">Need Help?</h3>
              <p className="text-blue-100 mb-6 text-sm">Our experts can help you choose the right branch based on your CET score.</p>
              <Link to="/contact" className="block w-full text-center bg-white text-blue-700 font-bold py-3 rounded-xl hover:bg-slate-50 transition">
                Consult an Advisor
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CollegeDetail;
