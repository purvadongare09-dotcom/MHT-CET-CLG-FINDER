
import React from 'react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white py-24 px-4">
        <div className="max-w-5xl mx-auto text-center space-y-8">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">
            Find Your Dream Engineering or Pharmacy College
          </h1>
          <p className="text-xl md:text-2xl text-blue-100 font-light max-w-3xl mx-auto">
            The most comprehensive MHT-CET college finder for Nagpur, Pune, and Mumbai. Simplified search for PCM & PCB streams.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 pt-4">
            <Link 
              to="/finder" 
              className="bg-white text-blue-700 px-8 py-4 rounded-xl font-bold text-lg hover:bg-slate-100 transition shadow-lg"
            >
              Start Finding Colleges
            </Link>
            <Link 
              to="/blog" 
              className="bg-blue-600 border border-blue-400 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-blue-500 transition shadow-lg"
            >
              View Latest Updates
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center p-8 border border-slate-100 rounded-2xl bg-slate-50">
            <h3 className="text-4xl font-bold text-blue-600">85+</h3>
            <p className="text-slate-600 font-medium">Top Tier Colleges</p>
          </div>
          <div className="text-center p-8 border border-slate-100 rounded-2xl bg-slate-50">
            <h3 className="text-4xl font-bold text-blue-600">3</h3>
            <p className="text-slate-600 font-medium">Major Districts (Nagpur, Pune, Mumbai)</p>
          </div>
          <div className="text-center p-8 border border-slate-100 rounded-2xl bg-slate-50">
            <h3 className="text-4xl font-bold text-blue-600">2</h3>
            <p className="text-slate-600 font-medium">Educational Streams (PCM & PCB)</p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900">Why Use MHT-CET Finder?</h2>
            <p className="text-slate-600 max-w-2xl mx-auto">We bridge the gap between students and their future institutions with verified information and easy navigation.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold text-xl">01</div>
              <h4 className="text-xl font-semibold">Verified Data</h4>
              <p className="text-slate-600 leading-relaxed">Every college listing includes NAAC scores, establishment years, and official website links verified for the 2024 academic year.</p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold text-xl">02</div>
              <h4 className="text-xl font-semibold">Step-by-Step Search</h4>
              <p className="text-slate-600 leading-relaxed">Our intuitive filter system helps you narrow down nearly 100 colleges to the perfect one for your specific stream and location.</p>
            </div>
            <div className="space-y-4">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center font-bold text-xl">03</div>
              <h4 className="text-xl font-semibold">Career Guidance</h4>
              <p className="text-slate-600 leading-relaxed">Our blog provides regular updates on CET exam patterns, counseling dates, and career paths in Engineering and Pharmacy.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4 bg-slate-900 text-white">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl font-bold">Ready to secure your admission?</h2>
          <p className="text-slate-400 text-lg">Don't wait for the last minute. Start researching your options today and be prepared for the CAP rounds.</p>
          <Link to="/finder" className="inline-block bg-blue-600 text-white px-10 py-4 rounded-full font-bold hover:bg-blue-700 transition">
            Browse College Database
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
