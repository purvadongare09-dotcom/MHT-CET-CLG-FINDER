
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="py-20 px-4 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        <div className="space-y-8">
          <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900">Empowering Students to Make Informed Choices</h1>
          <p className="text-lg text-slate-600 leading-relaxed">
            MHT-CET College Finder was founded with a single mission: to provide clear, accessible, and structured information to thousands of aspiring engineers and pharmacists in Maharashtra.
          </p>
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="w-6 h-6 rounded-full bg-blue-600 mt-1"></div>
              <div>
                <h4 className="font-bold">Unbiased Information</h4>
                <p className="text-slate-500">We do not take commissions from colleges. Our data is purely informational.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-6 h-6 rounded-full bg-blue-600 mt-1"></div>
              <div>
                <h4 className="font-bold">Up-to-Date Database</h4>
                <p className="text-slate-500">Our team constantly verifies establishment years and NAAC scores.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-6 h-6 rounded-full bg-blue-600 mt-1"></div>
              <div>
                <h4 className="font-bold">Student-Centric Design</h4>
                <p className="text-slate-500">Every feature is built based on actual feedback from CET aspirants.</p>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-slate-100 rounded-3xl aspect-square flex items-center justify-center p-12">
          <div className="text-center space-y-4">
            <div className="text-8xl">🎓</div>
            <h2 className="text-3xl font-bold">Trusted by 10k+ Students</h2>
            <p className="text-slate-500">Annually assisting in the admission journey across Maharashtra.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
