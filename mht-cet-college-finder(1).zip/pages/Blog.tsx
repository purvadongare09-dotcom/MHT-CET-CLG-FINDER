
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Post } from '../types';
import { getPosts } from '../store';

const Blog: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    setPosts(getPosts());
  }, []);

  return (
    <div className="py-20 px-4 max-w-5xl mx-auto">
      <div className="text-center mb-16 space-y-4">
        <h1 className="text-4xl font-extrabold text-slate-900">Latest Updates & Guidance</h1>
        <p className="text-slate-600">Stay informed about MHT-CET exam news and professional career advice.</p>
      </div>

      <div className="space-y-12">
        {posts.map(post => (
          <article key={post.id} className="group border-b border-slate-200 pb-12 last:border-0">
            <div className="flex flex-col md:flex-row gap-8">
              <div className="md:w-1/4">
                <time className="text-slate-400 font-bold uppercase tracking-widest text-sm">{post.date}</time>
              </div>
              <div className="md:w-3/4 space-y-4">
                <Link to={`/blog/${post.slug}`}>
                  <h2 className="text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition">{post.title}</h2>
                </Link>
                <p className="text-slate-600 leading-relaxed">{post.excerpt}</p>
                <Link to={`/blog/${post.slug}`} className="text-blue-600 font-bold hover:underline inline-block mt-2">Read More →</Link>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default Blog;
