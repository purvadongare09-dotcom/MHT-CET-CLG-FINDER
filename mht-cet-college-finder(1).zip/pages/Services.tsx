
import React from 'react';

const Services: React.FC = () => {
  const services = [
    { title: "College Comparison", description: "Compare up to 3 colleges side-by-side to see differences in infrastructure, NAAC ratings, and placement trends.", icon: "⚖️" },
    { title: "Counseling Support", description: "Expert advice on filling your option forms correctly to maximize your chances in CAP rounds.", icon: "🤝" },
    { title: "Admission Alerts", description: "Never miss a deadline with our real-time notification system for registration, merit lists, and round results.", icon: "🔔" },
    { title: "Document Checklist", description: "Personalized checklist generation based on your category (Open/OBC/SC/ST) for smooth verification.", icon: "📄" },
    { title: "Fee Structure Search", description: "Estimated fee details for various government and private colleges to help you plan your finances.", icon: "💰" },
    { title: "Branch Analysis", description: "In-depth insights into emerging engineering branches like AI, ML, and Data Science.", icon: "🧪" }
  ];

  return (
    <div className="py-20 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-16 space-y-4">
        <h1 className="text-4xl font-extrabold text-slate-900">Our Services</h1>
        <p className="text-slate-600 max-w-2xl mx-auto">We provide a comprehensive ecosystem of tools for students navigating the MHT-CET admission landscape.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((service, idx) => (
          <div key={idx} className="bg-white border border-slate-100 p-8 rounded-3xl shadow-sm hover:shadow-md transition">
            <div className="text-5xl mb-6">{service.icon}</div>
            <h3 className="text-xl font-bold mb-4">{service.title}</h3>
            <p className="text-slate-600">{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;
