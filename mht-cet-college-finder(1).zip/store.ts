
import { College, Post, SiteSettings } from './types';
import { INITIAL_COLLEGES, INITIAL_POSTS } from './constants';

const COLLEGES_KEY = 'mhtcet_finder_colleges';
const POSTS_KEY = 'mhtcet_finder_posts';
const SETTINGS_KEY = 'mhtcet_finder_settings';

export const getColleges = (): College[] => {
  const data = localStorage.getItem(COLLEGES_KEY);
  if (!data) {
    localStorage.setItem(COLLEGES_KEY, JSON.stringify(INITIAL_COLLEGES));
    return INITIAL_COLLEGES;
  }
  return JSON.parse(data);
};

export const saveColleges = (colleges: College[]) => {
  localStorage.setItem(COLLEGES_KEY, JSON.stringify(colleges));
};

export const getPosts = (): Post[] => {
  const data = localStorage.getItem(POSTS_KEY);
  if (!data) {
    localStorage.setItem(POSTS_KEY, JSON.stringify(INITIAL_POSTS));
    return INITIAL_POSTS;
  }
  return JSON.parse(data);
};

export const savePosts = (posts: Post[]) => {
  localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
};

export const getSettings = (): SiteSettings => {
  const data = localStorage.getItem(SETTINGS_KEY);
  if (!data) {
    const defaultSettings: SiteSettings = { 
      primaryColor: '#2563eb', 
      fontFamily: 'Inter',
      containerWidth: 'normal',
      showSidebarOnDetails: true
    };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(defaultSettings));
    return defaultSettings;
  }
  return JSON.parse(data);
};

export const saveSettings = (settings: SiteSettings) => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};
