
export enum Stream {
  PCM = 'PCM',
  PCB = 'PCB'
}

export enum District {
  NAGPUR = 'Nagpur',
  PUNE = 'Pune',
  MUMBAI = 'Mumbai'
}

export interface College {
  id: string;
  slug: string;
  name: string;
  stream: Stream;
  district: District;
  overview: string;
  address: string;
  estYear: string;
  naac: string;
  contact: string;
  website: string;
  metaTitle?: string;
  metaDesc?: string;
}

export interface Post {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  metaTitle?: string;
  metaDesc?: string;
}

export interface SiteSettings {
  primaryColor: string;
  fontFamily: string;
  containerWidth: 'narrow' | 'normal' | 'wide';
  showSidebarOnDetails: boolean;
}
